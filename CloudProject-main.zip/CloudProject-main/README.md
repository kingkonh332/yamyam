# CloudProject
클라우드 프로그래밍 개인 프로젝트 (영화 커뮤니티 사이트)
![image](https://user-images.githubusercontent.com/29898451/170617442-2493b67e-5c76-4d05-85ed-18b4fe1bf91f.png)
